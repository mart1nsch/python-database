from pathlib import Path
import os
import pandas as pd

CONFIG_PATH = './config/'
DATA_PATH = './data/'

def main():
    db = DataBase('project')
    #db.create_table('CLIENTE', ['ID', 'NOME', 'CPF'])
    #db.drop_table('CLIENTE')
    #db.insert('CLIENTE', ['3', 'Gustavo', '69'])
    #db.delete('CLIENTE', '1')
    #db.update('CLIENTE', '4', ['4', 'Tesouro', '99'])

class DataBase:
    db_name:str
    
    def __init__(self, name:str):
        self.db_name = name

    def return_table_path(self, table_name:str):
        return DATA_PATH + self.db_name + '/' + table_name + '.csv'

    def create_table(self, table_name:str, columns:list[str]):
        data_archive_path = self.return_table_path(table_name)

        p = Path(data_archive_path)

        if p.exists():
            raise Exception('ERR-0001 - Table already exists')

        columns_archive = ','
        columns_archive = columns_archive.join(columns) + '\n'

        with p.open(mode='w', encoding='utf-8') as f:
            f.write(columns_archive)
    
    def drop_table(self, table_name:str):
        data_archive_path = self.return_table_path(table_name)
        
        try:
            os.remove(data_archive_path)
        except FileNotFoundError as e:
            raise Exception("ERR-0002 - Table doesn't exist")

    def insert(self, table_name:str, col_values:list):
        data_archive_path = self.return_table_path(table_name)

        p = Path(data_archive_path)

        values_columns = ','
        values_columns = values_columns.join(col_values) + '\n'

        with p.open(mode='a', encoding='utf-8') as f:
            f.write(values_columns)

    def delete(self, table_name:str, id:str):
        data_archive_path = self.return_table_path(table_name)

        df = pd.read_csv(data_archive_path)
        
        df = df[df['ID'] != int(id)]

        df.to_csv(data_archive_path, index=False)

    def update(self, table_name:str, id:str, new_values:list):
        self.delete(table_name, id)
        self.insert(table_name, new_values)
    
if __name__ == '__main__':
    main()